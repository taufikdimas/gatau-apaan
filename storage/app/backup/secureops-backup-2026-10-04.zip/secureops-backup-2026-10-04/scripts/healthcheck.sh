#!/usr/bin/env bash
# ============================================================
# SecureOps Platform — Post-Restore Health Check
# Version: 1.3.0
# ============================================================

set -euo pipefail

CONF="${STAGING_DIR:-/opt/restore/staging}/config/services.conf"
LOG_FILE="/var/log/secureops/healthcheck-$(date +%Y%m%d-%H%M%S).log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S WIB')] $*" | tee -a "$LOG_FILE"; }

log "[INFO ] === Health Check ==="

PLATFORM_URL=$(grep -E '^platform_url\s*=' "$CONF" | awk -F'=' '{print $2}' | tr -d ' ')

# 1. HTTP connectivity
STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$PLATFORM_URL")
if [[ "$STATUS" == "200" || "$STATUS" == "302" ]]; then
  log "[OK  ] HTTP reachability: $PLATFORM_URL ($STATUS)"
else
  log "[FAIL] HTTP reachability: $PLATFORM_URL ($STATUS)"
fi

# 2. Database connectivity
if pg_isready -h db01.garuda-siber.internal -p 5432 -q; then
  log "[OK  ] PostgreSQL: db01.garuda-siber.internal:5432 accepting connections"
else
  log "[FAIL] PostgreSQL: not reachable"
fi

# 3. Redis
if redis-cli -h cache01.garuda-siber.internal -p 6379 PING | grep -q PONG; then
  log "[OK  ] Redis: cache01.garuda-siber.internal:6379 responding"
else
  log "[FAIL] Redis: not reachable"
fi

# 4. S3 backup bucket access
if aws s3 ls s3://garuda-siber-backups/ > /dev/null 2>&1; then
  log "[OK  ] S3 bucket access: garuda-siber-backups"
else
  log "[WARN] S3 bucket access: check AWS credentials"
fi

log "[INFO ] health check complete"
