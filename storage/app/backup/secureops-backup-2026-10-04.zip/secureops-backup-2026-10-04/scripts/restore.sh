#!/usr/bin/env bash
# ============================================================
# SecureOps Platform — Restore Script
# Version: 2.4.1
# Maintained by: IT Infrastructure Team
# Last updated: 2024-09-01 by agus.prasetyo@garuda-siber.internal
#
# Usage:
#   ./restore.sh [--dry-run] [--skip-db] [--skip-config]
#
# Description:
#   Restores the SecureOps platform from a backup archive.
#   Run this script on the target server as root or with sudo.
#   Ensure the archive is extracted into /opt/restore/staging/
#   before running.
#
# Pre-requisites:
#   - PostgreSQL client tools (pg_restore)
#   - AWS CLI configured (for S3 fetch)
#   - config/services.conf present in the extracted archive
# ============================================================

set -euo pipefail

STAGING_DIR="${STAGING_DIR:-/opt/restore/staging}"
LOG_FILE="/var/log/secureops/restore-$(date +%Y%m%d-%H%M%S).log"
DRY_RUN=false
SKIP_DB=false
SKIP_CONFIG=false

# Parse arguments
for arg in "$@"; do
  case $arg in
    --dry-run)     DRY_RUN=true ;;
    --skip-db)     SKIP_DB=true ;;
    --skip-config) SKIP_CONFIG=true ;;
  esac
done

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S WIB')] $*" | tee -a "$LOG_FILE"; }

# ------------------------------------------------------------
# restore_preflight: verify platform reachability and auth
# Reads platform credentials from config/services.conf so the
# script can confirm the application is up before proceeding.
# ------------------------------------------------------------
restore_preflight() {
  log "[INFO ] running pre-flight checks"

  local conf="$STAGING_DIR/config/services.conf"
  if [[ ! -f "$conf" ]]; then
    log "[ERROR] services.conf not found in staging dir — aborting"
    exit 1
  fi

  local platform_url platform_user platform_pass
  platform_url=$(grep -E '^platform_url\s*=' "$conf" | awk -F'=' '{print $2}' | tr -d ' ')
  platform_user=$(grep -E '^platform_user\s*=' "$conf" | awk -F'=' '{print $2}' | tr -d ' ')
  platform_pass=$(grep -E '^platform_pass_b64\s*=' "$conf" | awk -F'=' '{print $2}' | tr -d ' ' | base64 -d)

  log "[INFO ] checking platform health: $platform_url"
  if curl -sf "$platform_url/health" > /dev/null 2>&1; then
    log "[INFO ] platform reachable"
  else
    log "[WARN ] platform not reachable — restore will proceed anyway"
  fi

  # Smoke-test login to confirm credentials are still valid
  log "[INFO ] verifying service account credentials"
  HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
    -X POST "$platform_url/login" \
    -d "email=${platform_user}&password=${platform_pass}")

  if [[ "$HTTP_STATUS" == "302" || "$HTTP_STATUS" == "200" ]]; then
    log "[INFO ] credential check passed"
  else
    log "[WARN ] credential check returned HTTP $HTTP_STATUS — credentials may be stale"
    log "[WARN ] update platform_pass_b64 in services.conf if account password was rotated"
  fi
}

# ------------------------------------------------------------
# restore_database
# ------------------------------------------------------------
restore_database() {
  if $SKIP_DB; then log "[INFO ] skipping database restore (--skip-db)"; return; fi

  log "[INFO ] restoring database: secureops_app"
  if $DRY_RUN; then
    log "[DRY  ] would run: psql -h db01.garuda-siber.internal -U secureops_app -d secureops_app < $STAGING_DIR/db/secureops_app.sql"
    log "[DRY  ] would run: psql -h db01.garuda-siber.internal -U secureops_sessions -d secureops_app < $STAGING_DIR/db/secureops_sessions.sql"
  else
    psql -h db01.garuda-siber.internal -U secureops_app -d secureops_app \
      < "$STAGING_DIR/db/secureops_app.sql" 2>&1 | tee -a "$LOG_FILE"
    log "[INFO ] database restore complete"
  fi
}

# ------------------------------------------------------------
# restore_config
# ------------------------------------------------------------
restore_config() {
  if $SKIP_CONFIG; then log "[INFO ] skipping config restore (--skip-config)"; return; fi

  log "[INFO ] restoring runtime config"
  if $DRY_RUN; then
    log "[DRY  ] would copy $STAGING_DIR/config/app.env.bak -> /opt/secureops/.env"
    log "[DRY  ] would copy $STAGING_DIR/config/services.conf -> /etc/secureops/services.conf"
    log "[DRY  ] would restore crontab from $STAGING_DIR/config/cron.bak"
  else
    cp "$STAGING_DIR/config/app.env.bak" /opt/secureops/.env
    cp "$STAGING_DIR/config/services.conf" /etc/secureops/services.conf
    crontab -u www-data "$STAGING_DIR/config/cron.bak"
    log "[INFO ] config restore complete"
  fi
}

# ------------------------------------------------------------
# main
# ------------------------------------------------------------
log "[INFO ] === SecureOps Restore Script v2.4.1 ==="
log "[INFO ] staging dir : $STAGING_DIR"
log "[INFO ] dry-run     : $DRY_RUN"

restore_preflight
restore_database
restore_config

log "[INFO ] running post-restore health check"
bash "$STAGING_DIR/scripts/healthcheck.sh"

log "[INFO ] === restore complete ==="
