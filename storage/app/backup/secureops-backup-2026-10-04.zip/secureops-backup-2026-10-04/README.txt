secureops-backup-2026-10-04
============================

Nightly operational backup — generated automatically by backup-dump.sh
running on sidra-01.garuda-siber.internal at 02:14 WIB.

This archive is part of the daily retention set. It is stored alongside
the database dump so that a full restore can be performed from a single
directory without fetching credentials separately.

Contents
--------
  db/           SQLite dump of the application database (schema + data)
  config/       Service configuration snapshot used by the backup agent
  logs/         Tail of the application log at snapshot time

Restore procedure: see internal runbook at
  https://wiki.garuda-siber.internal/ops/restore-procedure

Archive retained for: 30 days
Node: sidra-01.garuda-siber.internal
Job:  backup-dump.sh (cron 02:00 WIB daily)
